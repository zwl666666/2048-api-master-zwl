#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 29 21:52:20 2018

@author: zwl
"""

import os

import keras

BATCH_SIZE = 128   
NUM_CLASSES = 4    
NUM_EPOCHS = 20   

from game2048.game import Game
from game2048.displays import Display
from game2048.agents import ExpectiMaxAgent,MyOwnAgent
from keras.models import Sequential,load_model
from keras.layers import Dense, Dropout, Flatten, Conv2D, MaxPooling2D,BatchNormalization
from keras.optimizers import RMSprop
import numpy as np
from sklearn.model_selection import train_test_split

image=[]
label=[]

display1 = Display()
display2 = Display()

stop_number = 2048
size = int(np.log2(stop_number)) +1    

for i in range(0,100):   
    game = Game(4, score_to_win=2048, random=False)
    agent = ExpectiMaxAgent(game, display=display1)  
    
    while game.end==False:
        a=np.array(game.board)
        
        direction=agent.step()
        image.append(game.board)
        label.append(direction)
        game.move(direction)
        if np.amax(a)==stop_number:
            break
       
    display1.display(game)
    
image=np.array(image)  
label=np.array(label)



x_train, x_test, y_train, y_test = train_test_split(image, label, test_size = 0.1, random_state= 30)

size = int(np.log2(stop_number)) +1    

input_shape = (4, 4, size)
x_train=np.log2(x_train+1)
x_train=np.trunc(x_train)
x_train = keras.utils.to_categorical(x_train, size) # one-hot
x_test=np.log2(x_test+1)
x_test=np.trunc(x_test)   
x_test = keras.utils.to_categorical(x_test, size)    




y_train = keras.utils.to_categorical(y_train, NUM_CLASSES)       
y_test = keras.utils.to_categorical(y_test, NUM_CLASSES)


model=Sequential()  
model.add(Conv2D(filters= 128, kernel_size=(4,1),kernel_initializer='he_uniform', padding='Same', activation='relu',input_shape=input_shape)) 
 
model.add(Conv2D(filters= 128, kernel_size=(1,4), kernel_initializer='he_uniform',padding='Same', activation='relu')) 

model.add(Conv2D(filters= 128, kernel_size=(1,1),kernel_initializer='he_uniform', padding='Same', activation='relu')) 

model.add(Conv2D(filters= 128, kernel_size=(2,2),kernel_initializer='he_uniform', padding='Same', activation='relu')) 

model.add(Conv2D(filters= 128, kernel_size=(3,3),kernel_initializer='he_uniform', padding='Same', activation='relu')) 

model.add(Conv2D(filters= 128, kernel_size=(4,4),kernel_initializer='he_uniform', padding='Same', activation='relu'))  

model.add(Flatten()) 
model.add(BatchNormalization())
model.add(Dense(256, kernel_initializer='he_uniform',activation='relu')) 
model.add(BatchNormalization())
model.add(Dense(128, kernel_initializer='he_uniform',activation='relu')) 

model.add(Dense(4, activation='softmax')) 

model.summary()
model.compile(optimizer='adam', loss = 'categorical_crossentropy',metrics=['accuracy'])
# train
model.fit(x_train, y_train, validation_data=(x_test, y_test), epochs=NUM_EPOCHS, batch_size=BATCH_SIZE, verbose=2)

# evaluate
score_train = model.evaluate(x_train, y_train, verbose=0)
print('Training loss: %.4f, Training accuracy: %.2f%%' % (score_train[0]*100,score_train[1]*100))
score_test = model.evaluate(x_test, y_test, verbose=0)
print('Testing loss: %.4f, Testing accuracy: %.2f%%' % (score_test[0]*100,score_test[1]*100))

model.save('first_model_last.h5')  
##########################################################################################################
##########################################################################################################
##########################################################################################################
####################以上为初步训练的模型，后续在此基础上改进##############################################

count = 0
image=[]
label=[]
while count<90:   
    
    image=[]
    label=[]   
    count = 0
    
    for k in range(0,100):
    
        game = Game(4, score_to_win=2048, random=False)
        agent = ExpectiMaxAgent(game, display=display1)  
        my_agent = MyOwnAgent(game, display=display2)  
    
        while game.end==False:
            direction1=agent.step()  
            
            x=np.array(game.board)
            temp=np.amax(x)
        
            x=np.log2(x+1)
            x=np.trunc(x)
            x = keras.utils.to_categorical(x, size)
            x = x.reshape(1, 4, 4, size)
            pred=model.predict(x,batch_size=128)
            r=pred[0]
            r1=r.tolist()
            direction2=r1.index(max(r1))         
        
            image.append(game.board)
            label.append(direction1)   
            game.move(direction2)     
            
        display1.display(game)    

        if temp == 1024:          
            count +=1
        
    if count >90:           
        break
    else:
        image=np.array(image)   
        label=np.array(label)

        x_train=np.log2(image+1)
        x_train=np.trunc(x_train)
        x_train = keras.utils.to_categorical(x_train, size) 

        y_train = keras.utils.to_categorical(label, NUM_CLASSES)       

        # train
        model.train_on_batch(x_train, y_train)

        model.save('model_2048_last.h5')  
        
        image=np.reshape(image,(-1,4))
        np.savetxt("image_last.txt",image)        
        np.savetxt("label_last.txt",label)
        


