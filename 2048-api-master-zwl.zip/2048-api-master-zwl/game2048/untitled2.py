# -*- coding: utf-8 -*-
"""
Created on Thu Dec 13 00:02:26 2018

@author: zwl
"""
import numpy as np
from game2048.agents import Agent
class YourOwnAgent(Agent):
    def step(self):
