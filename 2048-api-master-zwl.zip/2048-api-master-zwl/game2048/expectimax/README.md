# code by: [2048-ai](https://github.com/nneonneo/2048-ai)
A power agent that always pass 2048.

```bash
./configure
make
```